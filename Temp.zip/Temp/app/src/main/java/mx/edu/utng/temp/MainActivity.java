package mx.edu.utng.temp;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import mx.edu.utng.temp.R;

public class MainActivity extends AppCompatActivity {
    TextView txtGrados;
    TextView txtResultado;
    Button btnCentigrados;
    Button btnFahrenheit;
    double resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtGrados = (TextView)findViewById(R.id.txtGrados);
        txtResultado = (TextView)findViewById(R.id.txtResultado);
        btnCentigrados = (Button)findViewById(R.id.btnCen);
        btnFahrenheit = (Button)findViewById(R.id.btnFar);

        btnCentigrados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtResultado.setText("");
                if (txtGrados.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Ingresa una cantidad", Toast.LENGTH_SHORT).show();

                }
                else{
                    resultado = Double.parseDouble(String.valueOf(txtGrados.getText()));
                    resultado =(resultado*1.8)+32;
                    String resultadoGrado = String.valueOf(resultado);
                    txtResultado.setText(resultadoGrado);
                }

            }
        });

        btnFahrenheit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtResultado.setText("");
                if (txtGrados.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Ingresa una cantidad", Toast.LENGTH_SHORT).show();

                }
                else{
                    resultado = Double.parseDouble(String.valueOf(txtGrados.getText()));
                    resultado =(resultado-32)/1.8;
                    String resultadoGrado = String.valueOf(resultado);
                    txtResultado.setText(resultadoGrado);
                }

            }
        });

    }
}
